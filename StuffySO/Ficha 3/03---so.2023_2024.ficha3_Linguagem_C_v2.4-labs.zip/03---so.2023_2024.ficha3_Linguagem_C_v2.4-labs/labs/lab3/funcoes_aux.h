#ifndef _FUNCOES_AUX_H_
#define _FUNCOES_AUX_H_

float div_e_soma(float dividendo, float divisor);

#endif
