#ifndef _FUNCOES_H_
#define _FUNCOES_H_

float soma(float a, float b);

#endif
