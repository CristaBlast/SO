#include "funcoes.h"

float soma(float a, float b) { return a + b; }
